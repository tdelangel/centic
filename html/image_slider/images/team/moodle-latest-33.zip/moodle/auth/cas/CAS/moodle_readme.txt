Description of phpCAS 1.3.4 library import

* downloaded from http://downloads.jasig.org/cas-clients/php/current/

* MDL-59456 phpCAS library has been patched because of an authentication bypass security vulnerability.