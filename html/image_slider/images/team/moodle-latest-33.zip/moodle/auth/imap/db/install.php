<?php

function xmldb_auth_imap_install() {
    global $CFG, $DB;

}
